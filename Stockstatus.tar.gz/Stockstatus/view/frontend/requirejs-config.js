var config = {
    map: {
        '*': {
            web4prostockstatus: 'Web4pro_Stockstatus/js/stockstatus'
        }
    },

    paths:{
        web4prostockstatus: 'Web4pro_Stockstatus/js/stockstatus'
    }
};
